FLASK MINIPROJEKT

Gruppsmedlemar = Ivan, Bruno

github repo: https://github.com/OnizukaPy/jensen/tree/main/Utveckling%20av%20webbapplikationer/Flask/flask%20projekt

Istruktioner:

1 - exekvera pip install -r requirements.txt
2 - ladda ned zip-file från github
3 - extrakt filen och kör pythons coden app.py och följa istruktioner på skärmen 
